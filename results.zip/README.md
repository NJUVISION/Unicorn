* Folder **Unicorn_v1** are the results of TPAMI (https://ieeexplore.ieee.org/document/10682571 and https://ieeexplore.ieee.org/document/10682566).
* Folder **Unicorn_v2** are the results of the response of the Call for Proposals for AI-based Point Cloud Coding (m70061 & m70062 in https://dms.mpeg.expert/).
