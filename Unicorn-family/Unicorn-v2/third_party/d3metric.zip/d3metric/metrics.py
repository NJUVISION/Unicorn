"""
The copyright in this software is being made available under the BSD
Licence, included below.  This software may be subject to other third
party and contributor rights, including patent rights, and no such
rights are granted under this licence.

Copyright (c) 2017-2018, ISO/IEC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the ISO/IEC nor the names of its contributors
  may be used to endorse or promote products derived from this
  software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""

import os
import numpy as np
import scipy.spatial as spatial
import math
import time

import os, sys
rootdir_d3 = os.path.split(__file__)[0]
sys.path.append(rootdir_d3)
import d3_utils as ut


def mean_squared_error(data_a, data_b):
    """
    Calculate mean squared error

    Parameters
    ----------
    data_a : N x 1 float numpy.ndarray)
        array of values
    data_b : N x 1 float numpy.ndarray)
        array of values

    Returns
    -------
    mse : float
        mean squared error
    """

    mse = math.sqrt(sum(pow((data_a - data_b), 2)) / len(data_b))

    return mse


def d3psnr(pts_reference, pts_tested,
           bitdepth_psnr, mapsfolder, mapsprefix, diffradius, localaverage):
    """
    Density-to-density Peak Signal-to-noise Ratio

    Parameters
    ----------
    pts_reference : N x 3 numpy.ndarray
        x, y, z coordinates of N input points of reference point cloud
    pts_tested : M x 3 numpy.ndarray
        x, y, z coordinates of M input points of reference point cloud
    bitdepth_psnr : int
        number of bits used to define the peak value for PSNR calculation
    out_folder : str
        output density map folder for debug (if empty maps are not saved)
    out_filename : str
        output density difference map filename (used if save_maps_dbg is True
    diffradius : bool
        a flag that indicates the radius usage strategy
            True -> calculate different radii for pts_reference and pts_tested
            False -> calculate radius for pts_reference and apply the same radius to pts_tested
    localaverage: int
        a flag that indicates if avarage of local radius is used
            True -> save density maps for debugging
            False -> do not save density maps

    Returns
    -------
    d3_mse : float
        density-to-density mean squared error
    d3_psnr : float
        density-to-density peak signal-to-noise ration

    For reporting:
    nPtRef : int
        number of points in the reference poit cloud
    nPtsTes : int
        number of point in the tested point cloud
    radius_ref : float
        radius used to calculate local densities in the reference poit cloud
    radius_tes : float
        radius used to calculate local densities in the tested poit cloud
    """

    # Segment reference point cloud into blocks for average radius computation
    if localaverage:
        blk_size = 2**math.ceil(math.log2(pts_reference.max()))/32
    else:
        blk_size = 0

    # print('DBG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ut', ut)

    blks_reference = ut.geometry_partition(pts_reference, blk_size)

    # Radius estimation for reference point cloud
    radius_ref = 0
    for blk_ref in blks_reference:

        # Reference block information
        nPtsBlk = len(blk_ref)
        minCorner, maxCorner = ut.bounding_box(blk_ref)

        # Radius estimation for reference point cloud block
        radius_ref += ut.estimate_radius(nPtsBlk, minCorner, maxCorner)
    radius_ref = radius_ref/len(blks_reference)

    # Radius estimation for tested point cloud
    nPtsTes = len(pts_tested)

    if not diffradius:
        radius_tes = radius_ref
    else:
        blks_tested = ut.geometry_partition(pts_tested, blk_size)

        radius_tes = 0
        for blk_tes in blks_tested:

            # Reference point cloud block information
            nPtsBlk = len(blk_tes)
            minCorner, maxCorner = ut.bounding_box(blk_tes)

            # Radius estimation for reference point cloud block
            radius_tes += ut.estimate_radius(nPtsBlk, minCorner, maxCorner)
        radius_tes = radius_tes/len(blks_tested)

    # Number of point in the reference point cloud
    nPtsRef = len(pts_reference)

    # KDTree for neighborhood
    start = time.monotonic()
    point_tree_ref = spatial.cKDTree(pts_reference)
    point_tree_rec = spatial.cKDTree(pts_tested)
    print('K-D tree construction time: {0:5.2f} s'.format(time.monotonic()-start))

    # Compute density for each point
    start = time.monotonic()

    # Reference
    volRef = (4 * np.pi * pow(radius_ref, 3) / 3)
    densityRef = point_tree_ref.query_ball_point(pts_reference,
                                                 radius_ref,
                                                 workers=-1,
                                                 return_length=True).reshape(nPtsRef, 1) / volRef
    # Reconstructed
    volTes = (4 * np.pi * pow(radius_tes, 3) / 3)
    densityTes = point_tree_rec.query_ball_point(pts_reference,
                                                 radius_tes,
                                                 workers=-1,
                                                 return_length=True).reshape(nPtsRef, 1) / volTes

    print('Compute local density: {0:5.2f} s'.format(time.monotonic() - start))

    densityRefQ, densityTesQ = ut.quantize_density_maps(densityRef, densityTes, bitdepth_psnr)

    # Stack geometry and quantized density, and convert to sorted dataframe
    DfRefSorted = ut.sort_df_xyz(ut.geoattr2df(pts_reference, densityRefQ, 'float32', 'int', 1))
    DfRecSorted = ut.sort_df_xyz(ut.geoattr2df(pts_reference, densityTesQ, 'float32', 'int', 1))

    # Calc density-to-density PSNR (d3)
    d3_mse = mean_squared_error(np.array(DfRefSorted.iloc[:, -1:]), np.array(DfRecSorted.iloc[:, -1:]))
    d3_mse = max(d3_mse,1e-6)
    peakDensity = pow(2, bitdepth_psnr)-1
    d3_psnr = 20 * math.log10( peakDensity / d3_mse)

    #########
    # Debug #
    #########
    if mapsfolder != '':

        # Create output folder for density maps
        os.makedirs(mapsfolder, exist_ok=True)

        # bitdepth used to quantize the density difference maps for debug (visualization)
        bitdepth_dbg = 8

        start = time.monotonic()

        # Quantize reference and reconstructed density map for debug
        density_ref_norm, density_tes_norm = ut.quantize_density_maps(densityRef,
                                                                      densityTes,
                                                                      bitdepth_dbg)
        # Density difference map
        pts_num_neigh_diff = abs(densityRef - densityTes)
        peakAttrib = pow(2, bitdepth_dbg)-1
        density_dif_norm = np.round(peakAttrib * (
                    pts_num_neigh_diff - pts_num_neigh_diff.min()) /
                                    pts_num_neigh_diff.max() - pts_num_neigh_diff.min())

        # Save maps for visualization only
        ut.save_density_map_pyntc(os.path.join(mapsfolder, mapsprefix) + "_reference.ply",
                                  pts_reference, np.hstack([density_ref_norm] * 3))
        ut.save_density_map_pyntc(os.path.join(mapsfolder, mapsprefix) + "_tested.ply",
                                  pts_reference, np.hstack([density_tes_norm] * 3))
        ut.save_density_map_pyntc(os.path.join(mapsfolder, mapsprefix) + "_difference.ply",
                                  pts_reference, np.hstack([density_dif_norm] * 3))

        print('Save density maps: {0:5.2f} s'.format(time.monotonic() - start))

    return d3_mse, d3_psnr, nPtsRef, nPtsTes, radius_ref, radius_tes, blk_size



import argparse
import time
import os
def d3_args_fn():
    parser = argparse.ArgumentParser(prog='pc_error_d3.py',
                                     description='Density-to-density PSNR (d3-PSNR).',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--fileA',
                        help='Reference point cloud.',
                        default='../data/soldier_vox10_0690.ply')
    parser.add_argument('--fileB',
                        help='Tested point cloud.',
                        default='../data/soldier_vox10_0690.ply.bin.decoded.ply')
    parser.add_argument('--psnrbitdepth',
                        help='Bit-depth for peak density value used in PSNR calculation.',
                        type=int,
                        default=16)
    parser.add_argument('--diffradius',
                        help='Different radius are calculated for reference and tested point clouds.',
                        default=False,
                        action="store_true",)
    parser.add_argument('--localaverage',
                        help='Partition point cloud into blocks for local average radius estimation.',
                        default=False,
                        action="store_true")
    parser.add_argument('--keepduplicate',
                        help='Keep duplicate points from reference and tested point clouds.',
                        default=False,
                        action="store_true")
    parser.add_argument('--mapsfolder',
                        help='Density maps output folder (for visualization). If empty, maps are not saved.',
                        default='')
    parser.add_argument('--mapsnameprefix',
                        help='Prefix of output density maps name (for visualization).',
                        default='density_map')
    parser.add_argument('--reportfilepath',
                        help='Output report folder. If empty, results are printed on the screen.',
                        default='')
    d3_args = parser.parse_args()

    return d3_args