"""
The copyright in this software is being made available under the BSD
Licence, included below.  This software may be subject to other third
party and contributor rights, including patent rights, and no such
rights are granted under this licence.

Copyright (c) 2017-2018, ISO/IEC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the ISO/IEC nor the names of its contributors
  may be used to endorse or promote products derived from this
  software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""

import argparse
import time
import os

import os, sys
rootdir_d3 = os.path.split(__file__)[0]
sys.path.append(rootdir_d3)
from metrics import d3psnr
import d3_utils as ut



if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='pc_error_d3.py',
                                     description='Density-to-density PSNR (d3-PSNR).',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('--fileA',
                        help='Reference point cloud.',
                        default='../data/soldier_vox10_0690.ply')
    parser.add_argument('--fileB',
                        help='Tested point cloud.',
                        default='../data/soldier_vox10_0690.ply.bin.decoded.ply')
    parser.add_argument('--psnrbitdepth',
                        help='Bit-depth for peak density value used in PSNR calculation.',
                        type=int,
                        default=16)
    parser.add_argument('--diffradius',
                        help='Different radius are calculated for reference and tested point clouds.',
                        default=False,
                        action="store_true",)
    parser.add_argument('--localaverage',
                        help='Partition point cloud into blocks for local average radius estimation.',
                        default=False,
                        action="store_true")
    parser.add_argument('--keepduplicate',
                        help='Keep duplicate points from reference and tested point clouds.',
                        default=False,
                        action="store_true")
    parser.add_argument('--mapsfolder',
                        help='Density maps output folder (for visualization). If empty, maps are not saved.',
                        default='')
    parser.add_argument('--mapsnameprefix',
                        help='Prefix of output density maps name (for visualization).',
                        default='density_map')
    parser.add_argument('--reportfilepath',
                        help='Output report folder. If empty, results are printed on the screen.',
                        default='')
    args = parser.parse_args()

    start = time.monotonic()

    # Load point cloud geometry
    startload = time.monotonic()
    pts_A = ut.load_geometry(args.fileA, args.keepduplicate)
    pts_B = ut.load_geometry(args.fileB, args.keepduplicate)
    print('Load point clouds: {0:5.2f} s'.format(time.monotonic() - startload))

    print("Calculate d3-PSNR (A->A|B)")
    d3_mse1, d3_psnr1, nPtsA, nPtsB, radiusA_A, radiusB_A, blk_size = d3psnr(pts_A, pts_B,
                                                                             args.psnrbitdepth,
                                                                             args.mapsfolder,
                                                                             args.mapsnameprefix,
                                                                             args.diffradius,
                                                                             args.localaverage)
    runtime = time.monotonic() - start

    ut.print_report(args, nPtsA, nPtsB, radiusA_A, radiusB_A, blk_size,
                    d3_mse1, d3_psnr1, runtime)

    print("Done!")

