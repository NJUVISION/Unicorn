# Density-to-density PSNR (d3-PSNR)


## Requirements

pandas==1.1.5  
numpy==1.20.3  
open3d==0.13.0  
pyntcloud==0.1.4  
tabulate==0.8.10  
scipy==1.6.2  

```shell
pip install -r requirements.txt
```

## Examples

```shell
# Single global radius (default)
# Radius globally calculated for uncompressed point cloud is also applied to the decoded point cloud
python pc_error_d3.py --fileA ../data/uncompressed.ply --fileB ../data/decoded.ply

# Single local radius average (localaverage)
# Average of local radius is calculated for the uncompressed point cloud and also applied to the decoded point cloud
python pc_error_d3.py --fileA ../data/uncompressed.ply --fileB ../data/decoded.ply --localaverage

# Different global radius (diffradius)
# Globally calculate different radius for reference and tested point cloud
python pc_error_d3.py --fileA ../data/uncompressed.ply --fileB ../data/decoded.ply --diffradius

# Different local radius averages (localaverage-diffradius)
# Average of local radius is calculated for the uncompressed point cloud and the decoded point cloud
python pc_error_d3.py --fileA ../data/uncompressed.ply --fileB ../data/decoded.ply --localaverage --diffradius

# Save report in specified folder
python pc_error_d3.py --fileA ../data/uncompressed.ply --fileB ../data/decoded.ply --reportfilepath '../report/d3report.txt'

# Save density maps for visualization (debug)
python pc_error_d3.py --fileA ../data/uncompressed.ply --fileB --reportfilepath '../report/d3report.txt' --mapsfolder '../maps'
```

## Reference
   [1] MPEG input document m60331, "On Density-to-density Distortion", Alexandre Zaghetto, Danillo Graziosi, Ali Tabatabai     
   [2] MPEG output document w21692, "EE 5.0 on AI tools for PC compression and analysis"


