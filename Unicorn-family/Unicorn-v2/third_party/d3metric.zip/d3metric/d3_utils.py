"""
The copyright in this software is being made available under the BSD
Licence, included below.  This software may be subject to other third
party and contributor rights, including patent rights, and no such
rights are granted under this licence.

Copyright (c) 2017-2018, ISO/IEC
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of the ISO/IEC nor the names of its contributors
  may be used to endorse or promote products derived from this
  software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
"""

import numpy as np
import pandas as pd
import open3d as o3d
import sys
import os

from pyntcloud import PyntCloud
from tabulate import tabulate


def geometry_partition(geometry, block_size):
    """
    Partition point clouds into blocks

    Parameters
    ----------
    geometry : N x 3 float32 numpy.ndarray
        x, y, z coordinates of N input points
    block_size : int
        size of blocks

    Returns
    -------
    block_partitions_geometry : array of N x 3 float32 numpy.ndarray
        blocks of size block_size
    """

    if block_size == 0:
        block_partitions_geometry = [geometry]
    else:
        blk_labels, pt_label, pts_perBlock = np.unique(geometry // block_size, return_inverse=True, return_counts=True, axis=0)
        num_blocks = len(blk_labels)

        block_partitions_geometry = [np.zeros((num_points, 3), dtype=np.float32) for num_points in pts_perBlock]

        for blk in range(num_blocks):
            block_partitions_geometry[blk] = geometry[pt_label == blk, :]

    return block_partitions_geometry


def bounding_box(points):
    """
    Calculate bounding box

    Parameters
    ----------
    points : N x 3 float32 numpy.ndarray
        x, y, z coordinates of N input points

    Returns
    -------
    minCorner : 1 x 3 float32 numpy.ndarray
        x, y, z coordinates of top left corner of the bounding box
    maxCorner : 1 x 3 float32 numpy.ndarray
        x, y, z coordinates of bottom tight corner of the bounding box
    """

    minCorner = np.min(points, axis=0)
    maxCorner = np.max(points, axis=0)

    return minCorner, maxCorner


def estimate_radius(numpoints, mincorner, maxcorner, knn=64):
    """
    Estimate default radius. Based on GetDefaultCloudKernelSize implementation provided in:
    https://github.com/CloudCompare/CloudCompare/blob/a0ee03d973d2e7ebf8445c39cd9e35e4b459bdc7/qCC/ccLibAlgorithms.cpp

    Parameters
    ----------
    numpoints : int
        number of input points
    mincorner : 1 x 3 numpy.ndarray
        x, y, z coordinates of top left corner of the bounding box
    maxcorner : 1 x 3 numpy.ndarray
        x, y, z coordinates of bottom tight corner of the bounding box
    knn : int
        k-nearest neighbors

    Returns
    -------
    radius : float
        estimated radius for local density calculation
    """

    radius = float(max(np.round(np.sqrt(knn * pow(
        (maxcorner[0] - mincorner[0]) * (maxcorner[1] - mincorner[1]) * (
                maxcorner[2] - mincorner[2]), 2 / 3) / numpoints)), 1))

    return radius


def quantize_density_maps(density_map_a, density_map_b, bitdepth):
    """
    Quantize densities of reference and tested point clouds

    Parameters
    ----------
    bitdepth : int
        number of bits used to define the density peak value
    density_map_a : N x 1 float32 numpy.ndarray
        density maps for the reference point cloud
    density_map_b : N x 1 float32 numpy.ndarray)
        density maps for the tested point cloud

    Returns
    -------
    densityMapAq: N x 1 float32 numpy.ndarray
        quantized density maps for the reference point cloud
    densityMapBq: N x 1 float32 numpy.ndarray
        quantized density maps for the tested point cloud
    """

    densityMap = np.concatenate((density_map_a, density_map_b))

    maxDensity = densityMap.max()
    minDensity = densityMap.min()

    peakDensity = pow(2, bitdepth)-1

    # Quantization
    deltaDensity = (maxDensity - minDensity)
    densityMapAq = np.round(peakDensity * (density_map_a - minDensity) / deltaDensity)
    densityMapBq = np.round(peakDensity * (density_map_b - minDensity) / deltaDensity)

    return densityMapAq, densityMapBq


def geoattr2df(geometry, attribute, geometry_type='float32', attribute_type='int', nattrib=1):
    """
    Combine geometry and attribute into dataframe

    Parameters
    ----------
    geometry : N x 3 float32  numpy.ndarray
        x, y, z coordinates of N input points
    attribute : N x 1 float32 numpy.ndarray
        density values associated with each coordinate
    geometry_type : str
        type used to define the geometry
    attribute_type : str
        type used to define the attributes
    nattrib : int
        number of attributes
            (default = 1, density is stored as reflectance; if 3, density is stored as RGB)

    Returns
    -------
    pcloud : pandas.core.frame.DataFrame
        point cloud (density) information
            Columns = (x, y, z, reflectance or green, red, blue)
    """

    pc_columns = ["x", "y", "z"]
    pc_columns_types = dict([(coord, geometry_type) for coord in pc_columns])
    if nattrib == 1:
        pc_columns = pc_columns + ["reflectance"]
        pc_columns_types.update({'reflectance': attribute_type})
    else:
        pc_columns = pc_columns + ["green", "red", "blue"]
        pc_columns_types.update({'green': attribute_type, 'red': attribute_type, 'blue': attribute_type})

    pcloud = pd.DataFrame(np.hstack((geometry, attribute)), columns=pc_columns)
    pcloud = pcloud.astype(pc_columns_types)

    return pcloud


def sort_df_xyz(dataf):
    """
    Sort dataframe along x, y and z coordinate

    Parameters
    ----------
    dataf : pandas.core.frame.DataFrame
        point cloud (density) information

    Returns
    -------
    sortedDf : pandas.core.frame.DataFrame
        dataf sorted along x, y and z coordinate
    """

    sortedDf = dataf.sort_values(by=['x', 'y', 'z'])

    return sortedDf


def load_geometry(name, keepdup):
    """
    Load point cloud geometry only

    Parameters
    ----------
    name : str
        path to point cloud file
    keepdup : bool
        a flag used to indicate that duplicate points are note removed

    Returns
    -------
    geometry : N x 1 float32 numpy.ndarray
        point cloud geometry
    """

    assert os.path.exists(name),  "File not found: " + name

    geometry = PyntCloud.from_file(name).xyz

    if not keepdup:
        geometry = pd.DataFrame(geometry).drop_duplicates().values.astype(np.float32)

    return geometry


def save_density_map_o3d(pc_name, geometry, density, bitdepth_dbg):
    """
    Combine geometry and density and saves density map as a point cloud for visualization

    Parameters
    ----------
    pc_name : str
        path to point cloud file
    geometry : N x 1 float32 numpy.ndarray
        point cloud geometry
    density : N x 3 (G,R,B) float32 numpy.ndarray
        point cloud local density
    bitdepth_dbg : int
        number of bits used to define attribute normalization factor
    """

    densityMap = o3d.geometry.PointCloud()
    densityMap.points = o3d.utility.Vector3dVector(geometry)
    peakAttrib = pow(2, bitdepth_dbg)
    densityMap.colors = o3d.utility.Vector3dVector(density/peakAttrib)

    o3d.io.write_point_cloud(pc_name, densityMap, write_ascii=True)


def save_density_map_pyntc(pc_name, geometry, density, as_text=True):
    """
    Combine geometry and density and saves density map as a point cloud for visualization

    Parameters
    ----------
    pc_name : str
        path to point cloud file
    geometry : N x 1 float32 numpy.ndarray
        point cloud geometry
    density : N x 3 (G,R,B) float32 numpy.ndarray
        point cloud local density
    as_text: bool
        True: save point cloud as text
        False: save point cloud as binary
    """

    # Reconstructed
    densityMap = np.hstack((geometry, density))

    densityMapDF = pd.DataFrame(densityMap, columns=["x", "y", "z", "green", "blue", "red"])
    densityMapDF = densityMapDF.astype({'x': 'float32', 'y': 'float32', 'z': 'float32',
                                        'green': 'uint8', 'blue': 'uint8', 'red': 'uint8'})

    densityMapDF = densityMapDF.sort_values(by=['x', 'y', 'z'])

    densityMapPC = PyntCloud(densityMapDF)
    densityMapPC.to_file(pc_name, as_text=as_text)


# def print_report(d3_args, n_pts_ref, n_pts_tes, radiusA_A, radiusB_A, partition_size,
#                  d3_mse1, d3_psnr1, runtime):
#     """
#     Print report

#     Parameters
#     ----------
#     d3_args : argparse.Namespace
#         global simulation parameters
#     n_pts_ref : int
#         number of points in the reference poit cloud
#     n_pts_tes : int
#         number of point in the tested point cloud
#     radiusA_A : float
#         radius used to calculate local densities in poit cloud A when A is the reference
#     radiusB_A : float
#         radius used to calculate local densities in poit cloud B when A is the reference
#     partition_size
#         partition size use in radius calculation (if 0, no partition is performed)
#     d3_mse1 : float
#         A to B density-to-density mean squared error
#     d3_psnr1 : float
#         A to B density-to-density peak signal-to-noise ration
#     runtime : float
#         total processing time
#     """

#     if reportfilepath != '':

#         os.makedirs(os.path.split(reportfilepath)[0], exist_ok=True)

#         orig_stdout = sys.stdout
#         f = open(os.path.join(reportfilepath), 'w')
#         sys.stdout = f

#     print("Density-to-density quality measurement software, version 1.0")
#     print("Input parameters")
#     vd3_args = vars(d3_args)
#     paramTable = [[a, vd3_args[a]] for a in vd3_args] + \
#                  [["fileA number of points", n_pts_ref],
#                   ["fileB number of points", n_pts_tes],
#                   ["radius fileA", radiusA_A],
#                   ["radius fileB", radiusB_A],
#                   ["average radius", localaverage],
#                   ["partition size", partition_size],
#                   ["remove duplicates", not keepduplicate]]

#     print(tabulate(paramTable))

#     print("1. Use filaA as reference (loop over positions in filaA to calculate densities in fileA and fileB: A->A|B)")
#     print("mse1(density): {0:6.4f}".format(d3_mse1))
#     print("mse1, PSNR(density): {0:6.4f}".format(d3_psnr1))

#     print('Total processing time: {0:5.2f} s'.format(runtime))

#     if reportfilepath != '':
#         sys.stdout = orig_stdout
#         f.close()
#         print("Report saved in ", reportfilepath, '.')

#     if mapsfolder != '':
#         print("Density maps saved in", mapsfolder, '.')




def print_report(n_pts_ref, n_pts_tes, radiusA_A, radiusB_A, partition_size,
                 d3_mse1, d3_psnr1, runtime):
    """
    Print report

    Parameters
    ----------
    d3_args : argparse.Namespace
        global simulation parameters
    n_pts_ref : int
        number of points in the reference poit cloud
    n_pts_tes : int
        number of point in the tested point cloud
    radiusA_A : float
        radius used to calculate local densities in poit cloud A when A is the reference
    radiusB_A : float
        radius used to calculate local densities in poit cloud B when A is the reference
    partition_size
        partition size use in radius calculation (if 0, no partition is performed)
    d3_mse1 : float
        A to B density-to-density mean squared error
    d3_psnr1 : float
        A to B density-to-density peak signal-to-noise ration
    runtime : float
        total processing time
    """
    reportfilepath = ''
    localaverage = False
    keepduplicate = False
    mapsfolder = ''


    if reportfilepath != '':

        os.makedirs(os.path.split(reportfilepath)[0], exist_ok=True)

        orig_stdout = sys.stdout
        f = open(os.path.join(reportfilepath), 'w')
        sys.stdout = f

    print("Density-to-density quality measurement software, version 1.0")
    print("Input parameters")
    paramTable = [["fileA number of points", n_pts_ref],
                  ["fileB number of points", n_pts_tes],
                  ["radius fileA", radiusA_A],
                  ["radius fileB", radiusB_A],
                  ["average radius", localaverage],
                  ["partition size", partition_size],
                  ["remove duplicates", not keepduplicate]]

    print(tabulate(paramTable))

    print("1. Use filaA as reference (loop over positions in filaA to calculate densities in fileA and fileB: A->A|B)")
    print("mse1(density): {0:6.4f}".format(d3_mse1))
    print("mse1, PSNR(density): {0:6.4f}".format(d3_psnr1))

    print('Total processing time: {0:5.2f} s'.format(runtime))

    if reportfilepath != '':
        sys.stdout = orig_stdout
        f.close()
        print("Report saved in ", reportfilepath, '.')
    
    if mapsfolder != '':
        print("Density maps saved in", mapsfolder, '.')

